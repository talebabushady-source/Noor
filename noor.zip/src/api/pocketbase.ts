import { Client, Databases, Storage } from 'react-native-appwrite';
import { appwriteConfig } from '../config';
import { Book } from '../types/books';

const client = new Client()
  .setEndpoint(appwriteConfig.endpoint)
  .setProject(appwriteConfig.projectId);

const databases = new Databases(client);
const storage = new Storage(client);

// ذاكرة كاش مؤقتة للروابط المجلوبة لمنع إعادة الطلب بنفس الصفحة
const urlCache = new Map<string, string>();

export async function fetchBooks(): Promise<Book[]> {
  try {
    const response = await databases.listDocuments(
      appwriteConfig.databaseId,
      appwriteConfig.booksCollectionId
    );
    return response.documents as unknown as Book[];
  } catch (error) {
    console.error('خطأ أثناء جلب الكتب:', error);
    return [];
  }
}

/**
 * الحصول على رابط صفحة معينة مع اعتماد البادئة "hafs"
 * مثال اسم الملف: hafs_0001.jpg
 */
export async function getPageUrl(book: Book, pageNumber: number): Promise<string> {
  const padded = String(pageNumber).padStart(4, '0');
  const filename = `hafs_${padded}.jpg`;

  // 1. التفقّد من الكاش المحالي أولاً
  if (urlCache.has(filename)) {
    return urlCache.get(filename)!;
  }

  try {
    // 2. البحث عن الملف باسمه المباشر في Storage عبر معيار search
    const response = await storage.listFiles(
      appwriteConfig.mushafsBucketId,
      [], // عدم إرسال queries معقدة لتجنب مشاكل الصلاحيات
      filename // البحث المباشر باسم الملف
    );

    // البحث عن المطابقة الدقيقة لاسم الملف
    const matchedFile = response.files.find((f) => f.name === filename);

    if (matchedFile) {
      const fileUrl = storage.getFileView(appwriteConfig.mushafsBucketId, matchedFile.$id).toString();
      urlCache.set(filename, fileUrl);
      return fileUrl;
    }

    // 3. خيار إضافي: إذا كان File ID في Appwrite مسمى بنفس اسم الملف مباشرة
    const directUrl = storage.getFileView(appwriteConfig.mushafsBucketId, filename).toString();
    urlCache.set(filename, directUrl);
    return directUrl;

  } catch (error: any) {
    console.error(`خطأ أثناء تحميل الصفحة (${filename}):`, error);
    throw new Error(`تعذر تحميل الصفحة ${pageNumber}`);
  }
}

/**
 * الحصول على رابط ملف الفهرس: hafs_index.json
 */
export async function getIndexUrl(book: Book): Promise<string | null> {
  const filename = `hafs_index.json`;

  if (urlCache.has(filename)) {
    return urlCache.get(filename)!;
  }

  try {
    const response = await storage.listFiles(
      appwriteConfig.mushafsBucketId,
      [],
      filename
    );

    const matchedFile = response.files.find((f) => f.name === filename);

    if (matchedFile) {
      const fileUrl = storage.getFileView(appwriteConfig.mushafsBucketId, matchedFile.$id).toString();
      urlCache.set(filename, fileUrl);
      return fileUrl;
    }

    return null;
  } catch (error) {
    console.error('خطأ في جلب ملف الفهرس:', error);
    return null;
  }
}